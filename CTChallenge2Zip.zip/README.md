# CTChallenge2
Chris Thomas Challenge 2

Code written by me.
It's a bit ugly, but it's faster than my attempts to expedite it.

Separate VBA code saved as "CTStonks".

Excel file with the script already loaded in included as "Multiple_year_stock_dataCTanswer" (Script runs off of the Calc button on the Q1 sheet, script named "Stonks")

Screenshots of the top of the results of each sheet included as "Q1Screen," "Q2Screen," "Q3Screen," and "Q4Screen" respectively.