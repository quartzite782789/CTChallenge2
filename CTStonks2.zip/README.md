# CTChallenge2
Chris Thomas Challenge 2
V2.0
Code written by me.
Overhauled to explicitly read and store each row of raw data into intermediate arrays to then be processed into final output arrays, which finally are printed in the formatted output area

Separate VBA code saved as "CTStonks2".

Excel file with the script already loaded in included as "Multiple_year_stock_dataCTanswer2" (Script runs off of the Calc button on the Q1 sheet, script named "Stonks")

Screenshots of the top of the results of each sheet included as "Q1Screen," "Q2Screen," "Q3Screen," and "Q4Screen" respectively.